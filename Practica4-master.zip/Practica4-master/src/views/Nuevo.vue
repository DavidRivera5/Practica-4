<template>
<div>
    <header-title title="Nueva Página"/>
<p>
   Esta es la nueva página.
   </p> 
</div>
</template>

<script>
import HeaderTitle from '../components/HeaderTitle.vue'
export default {
   name:'Nuevo',
   components:{
       HeaderTitle
   }  
}
</script>